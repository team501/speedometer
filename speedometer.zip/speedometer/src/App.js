import React, { Component } from 'react';
import './App.css';
//import Speedometer from './SpeedoMeter';
import SpeedoMeterD3 from './ReactD3Guage';
import Speedo from './Speed.json'; 


class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
        <SpeedoMeterD3
									//percent={percentage} // Current Percentage value 
									needleLength={Speedo.needleLength} // Needle Length Range from 0 - 100
									needleRadius={Speedo.needleRadius} //Needle Radius Range from 0 - 10
									needleColor={Speedo.needleColor} //Needle Color can be hex vlaue or name of color
									barWidth={Speedo.barWidth} //Bar Width Range from be 0 - 50
									height={Speedo.height} //Speedometer Height
									width={Speedo.width} //Speedometer width
									textSize={Speedo.textSize} //Percentage Text Size
									segments={Speedo.segments} //Number of segments for speedometer
									segmentColors={Speedo.segmentColors} //segments colors for speedometer, default #000000
									segmentPercentage={Speedo.segmentPercentage} //segments percentage for speedometer
									
								/>
         
        </header>
      </div>
    );
  }
}

export default App;
